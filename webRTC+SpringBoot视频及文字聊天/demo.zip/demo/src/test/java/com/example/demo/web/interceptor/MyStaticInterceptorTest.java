package com.example.demo.web.interceptor;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * @Author: light-dragon
 * @Description:
 * @Date: Create in 19:03 2019/5/17
 */
public class MyStaticInterceptorTest {

    @Test
    public void preHandle() {
    }
}